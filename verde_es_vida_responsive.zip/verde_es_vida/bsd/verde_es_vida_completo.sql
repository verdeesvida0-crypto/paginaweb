-- Verde es Vida | Base de datos completa
CREATE DATABASE IF NOT EXISTS verde_es_vida
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE verde_es_vida;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre_completo VARCHAR(120) NOT NULL,
  correo VARCHAR(150) NOT NULL,
  contraseña VARCHAR(255) NOT NULL,
  rol ENUM('estudiante','profesor','visitante','administrador') NOT NULL DEFAULT 'visitante',
  grado VARCHAR(50) NULL,
  estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
  fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ultima_sesion DATETIME NULL,
  PRIMARY KEY (id_usuario),
  UNIQUE KEY uq_usuarios_correo (correo),
  KEY idx_usuarios_rol_estado (rol,estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Compatibilidad con instalaciones anteriores
ALTER TABLE usuarios MODIFY rol ENUM('estudiante','profesor','visitante','administrador') NOT NULL DEFAULT 'visitante';

CREATE TABLE IF NOT EXISTS proyectos (
  id_proyecto INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NOT NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT NOT NULL,
  categoria VARCHAR(80) NOT NULL DEFAULT 'Ambiental',
  estado ENUM('pendiente','aprobado','en_ejecucion','completado','rechazado') NOT NULL DEFAULT 'pendiente',
  meta VARCHAR(255) NULL,
  imagen VARCHAR(255) NULL,
  fecha_inicio DATE NULL,
  fecha_fin DATE NULL,
  fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_actualizacion TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_proyecto),
  KEY idx_proyectos_usuario (id_usuario),
  KEY idx_proyectos_estado (estado),
  CONSTRAINT fk_proyectos_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS participaciones (
  id_participacion INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_proyecto INT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  estado ENUM('pendiente','aceptada','rechazada') NOT NULL DEFAULT 'pendiente',
  fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_participacion),
  UNIQUE KEY uq_participacion (id_proyecto,id_usuario),
  KEY idx_part_usuario (id_usuario),
  CONSTRAINT fk_part_proyecto FOREIGN KEY (id_proyecto) REFERENCES proyectos(id_proyecto)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_part_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contactos (
  id_contacto INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NULL,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(150) NULL,
  rol VARCHAR(50) NULL,
  grado VARCHAR(50) NULL,
  asunto VARCHAR(180) NOT NULL,
  mensaje TEXT NOT NULL,
  canal ENUM('web','whatsapp') NOT NULL DEFAULT 'web',
  estado ENUM('nuevo','atendido','cerrado') NOT NULL DEFAULT 'nuevo',
  fecha_contacto TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_contacto),
  KEY idx_contactos_fecha (fecha_contacto),
  KEY idx_contactos_estado (estado),
  KEY idx_contactos_usuario (id_usuario),
  CONSTRAINT fk_contactos_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS whatsapp_eventos (
  id_evento BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NULL,
  id_contacto INT UNSIGNED NULL,
  telefono_destino VARCHAR(30) NOT NULL,
  asunto VARCHAR(180) NULL,
  fecha_evento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_evento),
  KEY idx_ws_fecha (fecha_evento),
  CONSTRAINT fk_ws_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_ws_contacto FOREIGN KEY (id_contacto) REFERENCES contactos(id_contacto)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS impactos (
  id_impacto INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NULL,
  id_proyecto INT UNSIGNED NULL,
  tipo ENUM('reciclaje','ecobotella','reutilizacion','arboles','otro') NOT NULL,
  cantidad DECIMAL(12,2) NOT NULL DEFAULT 0,
  unidad VARCHAR(30) NOT NULL,
  descripcion VARCHAR(255) NULL,
  fecha_impacto DATE NOT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_impacto),
  KEY idx_impactos_tipo_fecha (tipo,fecha_impacto),
  CONSTRAINT fk_impactos_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_impactos_proyecto FOREIGN KEY (id_proyecto) REFERENCES proyectos(id_proyecto)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS galeria (
  id_imagen INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NULL,
  titulo VARCHAR(160) NOT NULL,
  descripcion VARCHAR(255) NULL,
  archivo VARCHAR(255) NOT NULL,
  estado ENUM('visible','oculta') NOT NULL DEFAULT 'visible',
  fecha_subida TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_imagen),
  KEY idx_galeria_estado_fecha (estado,fecha_subida),
  CONSTRAINT fk_galeria_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ingresos_estudiantes (
  id_ingreso INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NOT NULL,
  fecha_ingreso TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_ingreso),
  KEY idx_ingresos_usuario (id_usuario),
  KEY idx_ingresos_fecha (fecha_ingreso),
  CONSTRAINT fk_ingresos_estudiante FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auditoria (
  id_auditoria BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario INT UNSIGNED NULL,
  accion VARCHAR(100) NOT NULL,
  tabla_afectada VARCHAR(80) NULL,
  id_registro BIGINT UNSIGNED NULL,
  detalle TEXT NULL,
  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_auditoria),
  KEY idx_auditoria_fecha (fecha),
  CONSTRAINT fk_auditoria_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La tabla antigua roles se conserva por compatibilidad, pero el sistema ya usa usuarios.rol.
CREATE TABLE IF NOT EXISTS roles (
  id INT NOT NULL AUTO_INCREMENT,
  estudiantes INT NOT NULL DEFAULT 0,
  profesores INT NOT NULL DEFAULT 0,
  visitantes INT NOT NULL DEFAULT 0,
  PRIMARY KEY(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;

-- IMPORTANTE:
-- Crea al menos un usuario con rol administrador desde phpMyAdmin.
-- La contraseña debe ser un hash generado con password_hash() de PHP.
-- Ejemplo: INSERT INTO usuarios (...) VALUES (..., '$2y$...', 'administrador', ...);
