<?php
require_once '../funciones.php'; require_once '../conexion.php'; require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('index.php'); verify_csrf();
$tipo=$_POST['tipo']??''; $id=(int)($_POST['id']??0); $estado=$_POST['estado']??''; $ok=false;
if($id<1){flash('admin_error','Registro no válido.');redirect('index.php');}
if($tipo==='proyecto' && in_array($estado,['pendiente','aprobado','en_ejecucion','completado','rechazado'],true)){ $s=$conexion->prepare('UPDATE proyectos SET estado=? WHERE id_proyecto=?'); $s->bind_param('si',$estado,$id); $ok=$s->execute(); $s->close(); if($ok) audit($conexion,(int)$_SESSION['id_usuario'],'cambiar_estado_proyecto','proyectos',$id,'Nuevo estado: '.$estado); }
elseif($tipo==='contacto' && in_array($estado,['nuevo','atendido','cerrado'],true)){ $s=$conexion->prepare('UPDATE contactos SET estado=? WHERE id_contacto=?'); $s->bind_param('si',$estado,$id); $ok=$s->execute(); $s->close(); if($ok) audit($conexion,(int)$_SESSION['id_usuario'],'cambiar_estado_contacto','contactos',$id,'Nuevo estado: '.$estado); }

elseif($tipo==='participacion' && in_array($estado,['pendiente','aceptada','rechazada'],true)){ $s=$conexion->prepare('UPDATE participaciones SET estado=? WHERE id_participacion=?'); $s->bind_param('si',$estado,$id); $ok=$s->execute(); $s->close(); if($ok) audit($conexion,(int)$_SESSION['id_usuario'],'cambiar_estado_participacion','participaciones',$id,'Nuevo estado: '.$estado); }
else { flash('admin_error','Datos inválidos.'); redirect('index.php'); }
$conexion->close(); flash($ok?'admin_ok':'admin_error',$ok?'Cambio guardado correctamente.':'No se pudo guardar el cambio.'); redirect('index.php');
?>
