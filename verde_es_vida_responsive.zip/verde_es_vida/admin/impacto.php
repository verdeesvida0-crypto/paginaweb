<?php
require_once '../funciones.php'; require_once '../conexion.php'; require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('index.php'); verify_csrf();
$tipo=$_POST['tipo']??'otro'; $permitidos=['reciclaje','ecobotella','reutilizacion','arboles','otro'];
if(!in_array($tipo,$permitidos,true)) {flash('admin_error','Tipo de impacto inválido.');redirect('index.php');}
$cantidad=(float)($_POST['cantidad']??-1); $unidad=trim($_POST['unidad']??'unidad'); $fecha=$_POST['fecha_impacto']??date('Y-m-d'); $desc=trim($_POST['descripcion']??'');
if($cantidad<0 || $cantidad>9999999999){flash('admin_error','La cantidad debe ser un valor válido.');redirect('index.php');}
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$fecha)){flash('admin_error','La fecha no es válida.');redirect('index.php');}
if($unidad===''||mb_strlen($unidad)>30){flash('admin_error','La unidad no es válida.');redirect('index.php');}
$s=$conexion->prepare('INSERT INTO impactos(id_usuario,tipo,cantidad,unidad,descripcion,fecha_impacto) VALUES(?,?,?,?,?,?)'); $idu=(int)$_SESSION['id_usuario']; $s->bind_param('isdsss',$idu,$tipo,$cantidad,$unidad,$desc,$fecha);
if($s->execute()){audit($conexion,$idu,'registrar_impacto','impactos',(int)$s->insert_id,'Tipo: '.$tipo.'; cantidad: '.$cantidad.' '.$unidad);flash('admin_ok','Impacto registrado correctamente.');} else flash('admin_error','No se pudo registrar el impacto.');
$s->close();$conexion->close();redirect('index.php');
?>
