<?php
require_once '../funciones.php'; require_once '../conexion.php'; require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('usuarios.php'); verify_csrf();
$id=(int)($_POST['id_usuario']??0); $rol=$_POST['rol']??'visitante'; $estado=$_POST['estado']??'activo'; $nueva=$_POST['nueva_contrasena']??'';
$roles=['estudiante','profesor','visitante','administrador']; $estados=['activo','inactivo'];
if($id<1 || !in_array($rol,$roles,true) || !in_array($estado,$estados,true)){flash('admin_usuario_error','Datos inválidos.');redirect('usuarios.php');}
if($id===(int)$_SESSION['id_usuario'] && ($rol!=='administrador'||$estado!=='activo')){flash('admin_usuario_error','No puedes quitarte a ti mismo el rol de administrador ni desactivar tu propia cuenta.');redirect('usuarios.php');}
$s=$conexion->prepare('UPDATE usuarios SET rol=?, estado=? WHERE id_usuario=?'); $s->bind_param('ssi',$rol,$estado,$id); $ok=$s->execute(); $s->close();
if(!$ok){flash('admin_usuario_error','No se pudo actualizar el usuario.');redirect('usuarios.php');}
if($nueva!==''){if(strlen($nueva)<8){flash('admin_usuario_error','La nueva contraseña debe tener al menos 8 caracteres.');redirect('usuarios.php');}$hash=password_hash($nueva,PASSWORD_DEFAULT);$s=$conexion->prepare('UPDATE usuarios SET contraseña=? WHERE id_usuario=?');$s->bind_param('si',$hash,$id);$s->execute();$s->close();}
$admin=(int)$_SESSION['id_usuario'];$detalle='Actualizó usuario ID '.$id.'; rol='.$rol.'; estado='.$estado.($nueva!==''?' y restableció contraseña':'');$s=$conexion->prepare("INSERT INTO auditoria(id_usuario,accion,tabla_afectada,id_registro,detalle) VALUES(?, 'admin_usuario', 'usuarios', ?, ?)");if($s){$s->bind_param('iis',$admin,$id,$detalle);$s->execute();$s->close();}$conexion->close();flash('admin_usuario_ok','Usuario actualizado correctamente.');redirect('usuarios.php');
